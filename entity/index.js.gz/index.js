module.exports = {
    Cell: require('./Cell'),
    PlayerCell: require('./PlayerCell'),
    Food: require('./Food'),
    Virus: require('./Virus'),
    EjectedMass: require('./EjectedMass'),
};

